import { CONTACT, FLEET } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import { BagIcon, CheckIcon, UsersIcon } from "@/components/icons";
import { slug, trackCta } from "@/lib/tracking";

export function Fleet() {
  return (
    <section id="fleet" className="section-y bg-surface">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Our Fleet</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            Choose the Right Vehicle for Your Journey
          </h2>
          <p className="mt-4 text-base text-muted-foreground">
            From budget sedans to luxury tempo travellers and buses — clean, AC and
            well-maintained, with transparent per-kilometre pricing.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FLEET.map((v, i) => (
            <Reveal key={v.name} delay={(i % 3) * 70} className="h-full">
              <article className="flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                <div className="aspect-16/10 overflow-hidden bg-surface p-4">
                  <img
                    src={v.image}
                    alt={`${v.name} — ${v.model}`}
                    loading="lazy"
                    decoding="async"
                    width={560}
                    height={350}
                    className="h-full w-full object-contain"
                  />
                </div>
                <div className="flex flex-1 flex-col border-t border-border p-6">
                  <div>
                    <h3 className="text-lg font-bold text-ink">{v.name}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{v.model}</p>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-semibold text-ink-soft">
                      <UsersIcon className="h-3.5 w-3.5" />
                      {v.passengers}
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-semibold text-ink-soft">
                      <BagIcon className="h-3.5 w-3.5" />
                      {v.bags}
                    </span>
                  </div>

                  <ul className="mt-4 space-y-2">
                    {v.features.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-sm text-ink-soft">
                        <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <a
                    href={`https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(`Hello Shri Travels, I would like to enquire about ${v.name}.`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => trackCta({
                      ctaId: `fleet_${slug(v.name)}_book_now`,
                      ctaName: "WhatsApp Now",
                      ctaType: "whatsapp",
                      section: "Fleet",
                      vehicle: v.name,
                    })}
                    className="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105"
                  >
                    WhatsApp Now
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
