import { useEffect, useRef, useState } from "react";
import { STATS } from "@/data/site";

function useCountUp(target: number, decimals = 0) {
  const ref = useRef<HTMLDivElement>(null);
  const [value, setValue] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setValue(target);
      return;
    }
    const io = new IntersectionObserver((entries) => {
      if (!entries[0]?.isIntersecting) return;
      io.disconnect();
      const duration = 1600;
      const start = performance.now();
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / duration);
        const eased = 1 - Math.pow(1 - p, 3);
        setValue(target * eased);
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => io.disconnect();
  }, [target]);

  return { ref, display: value.toFixed(decimals) };
}

function Stat({
  value,
  suffix,
  label,
  decimals,
}: {
  value: number;
  suffix: string;
  label: string;
  decimals?: number;
}) {
  const { ref, display } = useCountUp(value, decimals ?? 0);
  return (
    <div ref={ref} className="text-center">
      <p className="font-display text-4xl font-extrabold text-primary sm:text-5xl">
        {display}
        {suffix}
      </p>
      <p className="mt-2 text-sm font-semibold tracking-wide text-ink-soft sm:text-base">
        {label}
      </p>
    </div>
  );
}

export function Stats() {
  return (
    <section className="border-y border-border bg-card">
      <div className="container-x py-12 md:py-16">
        <h2 className="text-center font-display text-2xl font-extrabold text-ink sm:text-3xl">
          Numbers Speak ❤️
        </h2>
        <div className="mt-8 grid grid-cols-2 gap-8 lg:grid-cols-4">
          {STATS.map((s) => (
            <Stat
              key={s.label}
              value={s.value}
              suffix={s.suffix}
              label={s.label}
              decimals={s.decimals ?? 0}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
