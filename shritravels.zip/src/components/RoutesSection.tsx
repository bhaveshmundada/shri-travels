import { CONTACT, ROUTES } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import { ClockIcon, RouteIcon } from "@/components/icons";
import { slug, trackCta } from "@/lib/tracking";

export function RoutesSection() {
  return (
    <section id="routes" className="section-y bg-background">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Popular Routes</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            Outstation Cab Routes from Solapur
          </h2>
          <p className="mt-4 text-base text-muted-foreground">
            Fixed, transparent routes with clear distance and travel time — pick yours and
            book in seconds.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {ROUTES.map((r, i) => (
            <Reveal key={r.to} delay={(i % 3) * 70} className="h-full">
              <article className="flex h-full flex-col rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lift">
                <div className="flex items-center gap-2 text-lg font-bold text-ink">
                  <RouteIcon className="h-5 w-5 text-primary" />
                  <span>
                    {r.from} <span className="text-muted-foreground">→</span> {r.to}
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold text-ink-soft">
                    {r.distance}
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-semibold text-ink-soft">
                    <ClockIcon className="h-3.5 w-3.5" />
                    {r.duration}
                  </span>
                </div>
                {r.description.map((p) => (
                  <p key={p} className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {p}
                  </p>
                ))}
                <a
                  href={`https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(`Hello Shri Travels, I would like to enquire about a cab from ${r.from} to ${r.to}.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackCta({
                    ctaId: `route_${slug(r.from)}_${slug(r.to)}_book_now`,
                    ctaName: "WhatsApp Now",
                    ctaType: "whatsapp",
                    section: "Popular Routes",
                    route: `${r.from} to ${r.to}`,
                  })}
                  className="mt-auto block pt-5"
                >
                  <span className="block w-full rounded-xl bg-primary px-5 py-3 text-center text-sm font-semibold text-primary-foreground transition-all hover:brightness-105">
                    WhatsApp Now
                  </span>
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
