import { CONTACT, IMAGES, STATS } from "@/data/site";
import { CheckIcon, PhoneIcon, StarIcon, WhatsAppIcon } from "@/components/icons";
import { trackCta } from "@/lib/tracking";

const TRUST = ["24x7 Support", "Experienced Drivers", "Affordable Rates"];

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-surface">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 -right-32 h-[32rem] w-[32rem] rounded-full bg-primary/10 blur-3xl"
      />
      <div className="container-x relative grid items-center gap-10 py-12 md:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:gap-14">
        <div>
          <span className="eyebrow">Solapur’s Most Trusted Cab Service</span>
          <h1 className="mt-5 text-4xl leading-[1.08] font-extrabold text-ink sm:text-5xl lg:text-6xl">
            Safe, Comfortable &{" "}
            <span className="text-primary">On-Time Rides</span>
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Book reliable cabs from Solapur to Tuljapur, Pandharpur, Akkalkot, Gangapur,
            Satara, Sangli, Pune &amp; Mumbai. Clean vehicles, professional drivers, and
            transparent pricing for every journey.
          </p>

          <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
            {TRUST.map((t) => (
              <li key={t} className="flex items-center gap-2 text-sm font-semibold text-ink-soft">
                <CheckIcon className="h-4 w-4 text-success" />
                {t}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href={`tel:${CONTACT.phoneDial}`}
              onClick={() =>
                trackCta({
                  ctaId: "hero_book_now",
                  ctaName: "Call Now",
                  ctaType: "call",
                  section: "Hero",
                })
              }
              className="inline-flex items-center justify-center rounded-xl bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-lift transition-all hover:brightness-105"
            >
              <PhoneIcon className="mr-2 h-5 w-5" />
              Call Now
            </a>
            <a
              href={`https://wa.me/${CONTACT.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() =>
                trackCta({
                  ctaId: "hero_whatsapp",
                  ctaName: "Whatsapp Now",
                  ctaType: "whatsapp",
                  section: "Hero",
                })
              }
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-7 py-3.5 text-base font-semibold text-ink shadow-soft transition-colors hover:border-success hover:text-success"
            >
              <WhatsAppIcon className="h-5 w-5 text-success" />
              WhatsApp Now
            </a>
          </div>

          <div className="mt-8 flex items-center gap-3">
            <div className="flex text-primary" aria-hidden="true">
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} />
              ))}
            </div>
            <p className="text-sm text-muted-foreground">
              <strong className="text-ink">{STATS[3]?.value}</strong> rating on Google from{" "}
              <strong className="text-ink">5223+</strong> happy customers
            </p>
          </div>
        </div>

        <div className="relative">
          <img
            src={IMAGES.hero}
            alt="Shri Travels cab service in Solapur"
            width={720}
            height={480}
            fetchPriority="high"
            className="mx-auto w-full max-w-xl rounded-3xl object-contain"
          />
        </div>
      </div>

    </section>
  );
}
