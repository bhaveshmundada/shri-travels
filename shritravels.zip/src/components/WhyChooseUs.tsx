import { BENEFITS, CONTACT, WHY_POINTS } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import {
  CheckIcon,
  PhoneIcon,
  HeadsetIcon,
  ShieldIcon,
  SparkleIcon,
  WalletIcon,
  WhatsAppIcon,
} from "@/components/icons";
import { trackCta } from "@/lib/tracking";

const ICONS = [SparkleIcon, HeadsetIcon, ShieldIcon, WalletIcon];

export function WhyChooseUs() {
  return (
    <section id="about" className="section-y bg-background">
      <div className="container-x grid gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
        <div>
          <span className="eyebrow">Why Choose Us</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            Why Choose Shri Travels
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            We make your temple journeys peaceful and comfortable with clean vehicles,
            experienced drivers, and honest pricing — trusted by thousands of families
            across Solapur.
          </p>

          <ul className="mt-7 space-y-3">
            {WHY_POINTS.map((p) => (
              <li key={p} className="flex items-center gap-3 text-base font-semibold text-ink">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-success/12 text-success">
                  <CheckIcon className="h-4 w-4" />
                </span>
                {p}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href={`tel:${CONTACT.phoneDial}`}
              onClick={() => trackCta({ ctaId: "why_choose_us_book_now", ctaName: "Call Now", ctaType: "call", section: "Why Choose Us" })}
              className="inline-flex items-center justify-center rounded-xl bg-primary px-7 py-3.5 text-base font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105"
            >
              <PhoneIcon className="mr-2 h-5 w-5" />
              Call Now
            </a>
            <a
              href={`https://wa.me/${CONTACT.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() =>
                trackCta({
                  ctaId: "why_choose_us_whatsapp",
                  ctaName: "Whatsapp Now",
                  ctaType: "whatsapp",
                  section: "Why Choose Us",
                })
              }
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-border px-7 py-3.5 text-base font-semibold text-ink transition-colors hover:border-success hover:text-success"
            >
              <WhatsAppIcon className="h-5 w-5 text-success" />
              WhatsApp Now
            </a>
          </div>
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          {BENEFITS.map((b, i) => {
            const Icon = ICONS[i] ?? SparkleIcon;
            return (
              <Reveal key={b.title} delay={i * 80} className="h-full">
                <div className="h-full rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary-soft text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-4 text-lg font-bold text-ink">{b.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.text}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
