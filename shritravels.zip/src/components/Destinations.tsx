import { CONTACT, DESTINATIONS } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import { CheckIcon, PhoneIcon } from "@/components/icons";
import { slug, trackCta } from "@/lib/tracking";

export function Destinations() {
  return (
    <section id="destinations" className="section-y bg-background">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Temple Destinations</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            Visit the Most Holy Temples Near Solapur with Peaceful, Hassle-Free Rides
          </h2>
          <p className="mt-4 text-base text-muted-foreground">
            Explore the divine temples around Solapur with comfortable, safe, and
            well-planned cab services. Perfect for families, groups, and senior citizens
            seeking a peaceful darshan experience.
          </p>
        </div>

        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {DESTINATIONS.map((d, i) => (
            <Reveal key={d.location} delay={i * 70}>
              <article className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-lift">
                <div className="relative aspect-16/10 overflow-hidden bg-surface">
                  <img
                    src={d.image}
                    alt={d.title}
                    loading="lazy"
                    decoding="async"
                    width={640}
                    height={400}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <p className="text-xs font-bold tracking-[0.14em] text-primary uppercase">
                    {d.location}
                  </p>
                  <h3 className="mt-2 text-xl font-bold text-ink">{d.title}</h3>
                  {d.description.map((p) => (
                    <p key={p} className="mt-3 text-sm leading-relaxed text-muted-foreground">
                      {p}
                    </p>
                  ))}
                  <ul className="mt-4 space-y-2">
                    {d.features.map((f) => (
                      <li key={f} className="flex items-start gap-2 text-sm text-ink-soft">
                        <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <a
                    href={`tel:${CONTACT.phoneDial}`}
                    onClick={() =>
                      trackCta({
                        ctaId: `destination_${slug(d.location)}_book_now`,
                        ctaName: "Call Now",
                        ctaType: "call",
                        section: "Temple Destinations",
                        destination: d.location,
                      })
                    }
                    className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105"
                  >
                    <PhoneIcon className="h-5 w-5" />
                    Call Now
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
