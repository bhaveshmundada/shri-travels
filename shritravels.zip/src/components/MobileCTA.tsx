import { CONTACT } from "@/data/site";
import { PhoneIcon, WhatsAppIcon } from "@/components/icons";
import { trackCta } from "@/lib/tracking";

export function MobileCTA() {

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur-md lg:hidden">
      <div className="flex items-center gap-2 px-3 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))]">
        <a
          href={`tel:${CONTACT.phoneDial}`}
          onClick={() =>
            trackCta({
              ctaId: "mobile_call",
              ctaName: "Call",
              ctaType: "call",
              section: "Mobile Sticky CTA",
            })
          }
          className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground"
          aria-label={`Call ${CONTACT.phone}`}
        >
          <PhoneIcon />
          Call Now
        </a>
        <a
          href={`https://wa.me/${CONTACT.whatsapp}`}
          target="_blank"
          rel="noopener noreferrer"
          onClick={() =>
            trackCta({
              ctaId: "mobile_whatsapp",
              ctaName: "WhatsApp Now",
              ctaType: "whatsapp",
              section: "Mobile Sticky CTA",
            })
          }
          className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105"
        >
          <WhatsAppIcon className="h-5 w-5" />
          WhatsApp Now
        </a>
      </div>
    </div>
  );
}
