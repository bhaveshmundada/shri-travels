import { useEffect, useState } from "react";
import logo from "@/assets/shri-travels-logo.png.asset.json";
import { CONTACT } from "@/data/site";
import { PhoneIcon } from "@/components/icons";
import { trackCta } from "@/lib/tracking";

const NAV = [
  { label: "Home", href: "#home" },
  { label: "About Us", href: "#about" },
  { label: "Packages", href: "#packages" },
  { label: "Contact", href: "#contact" },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 w-full border-b transition-all ${
        scrolled
          ? "border-border bg-background/90 shadow-soft backdrop-blur-md"
          : "border-transparent bg-background"
      }`}
    >
      <div className="container-x flex h-18 items-center justify-between gap-4 py-3">
        <a href="#home" className="flex items-center gap-2.5" aria-label="Shri Travels home">
          <img
            src={logo.url}
            alt="Shri Travels logo"
            width={44}
            height={44}
            className="h-11 w-11 object-contain"
          />
          <span className="font-display text-lg font-extrabold tracking-tight text-ink sm:text-xl">
            Shri Travels
          </span>
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {NAV.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="rounded-lg px-3.5 py-2 text-sm font-semibold text-ink-soft transition-colors hover:bg-muted hover:text-primary"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <a
            href={`tel:${CONTACT.phoneDial}`}
            onClick={() =>
              trackCta({
                ctaId: "header_call",
                ctaName: "Call Number",
                ctaType: "call",
                section: "Header",
              })
            }
            className="hidden items-center gap-2 rounded-xl border border-border px-3.5 py-2.5 text-sm font-semibold text-ink transition-colors hover:border-primary hover:text-primary sm:inline-flex"
          >
            <PhoneIcon className="h-4 w-4 text-primary" />
            {CONTACT.phone}
          </a>
          <a
            href={`https://wa.me/${CONTACT.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackCta({ ctaId: "header_whatsapp", ctaName: "WhatsApp Now", ctaType: "whatsapp", section: "Header" })}
            className="hidden rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105 sm:inline-flex"
          >
            WhatsApp Now
          </a>
          <button
            type="button"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
            className="grid h-11 w-11 place-items-center rounded-xl border border-border text-ink lg:hidden"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              {open ? <path d="M18 6 6 18M6 6l12 12" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="container-x flex flex-col py-3" aria-label="Mobile">
            {NAV.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-2 py-3 text-base font-semibold text-ink-soft hover:text-primary"
              >
                {item.label}
              </a>
            ))}
            <a
              href={`tel:${CONTACT.phoneDial}`}
              onClick={() =>
                trackCta({
                  ctaId: "mobile_nav_call",
                  ctaName: "Call Number",
                  ctaType: "call",
                  section: "Mobile Navigation",
                })
              }
              className="mt-1 inline-flex items-center gap-2 rounded-lg px-2 py-3 text-base font-semibold text-primary"
            >
              <PhoneIcon className="h-4 w-4" />
              {CONTACT.phone}
            </a>
            <a
              href={`https://wa.me/${CONTACT.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                setOpen(false);
                trackCta({ ctaId: "mobile_nav_whatsapp", ctaName: "WhatsApp Now", ctaType: "whatsapp", section: "Mobile Navigation" });
              }}
              className="mt-2 mb-3 rounded-xl bg-primary px-5 py-3 text-base font-semibold text-primary-foreground"
            >
              WhatsApp Now
            </a>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
