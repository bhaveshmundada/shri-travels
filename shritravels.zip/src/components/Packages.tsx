import { CONTACT, PACKAGES } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import { CheckIcon, ClockIcon, PinIcon } from "@/components/icons";
import { slug, trackCta } from "@/lib/tracking";

export function Packages() {
  return (
    <section id="packages" className="section-y bg-surface">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Darshan Packages</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            Ready-Made Pilgrimage Packages from Solapur
          </h2>
          <p className="mt-4 text-base text-muted-foreground">
            Thoughtfully planned temple tours with fixed routes, comfortable vehicles, and
            drivers who know the darshan timings.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {PACKAGES.map((p, i) => (
            <Reveal key={p.name} delay={i * 80} className="h-full">
              <article className="flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lift">
                <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-primary-soft px-3 py-1.5 text-xs font-bold text-accent-foreground">
                  <ClockIcon className="h-3.5 w-3.5" />
                  {p.duration}
                </span>
                <h3 className="mt-4 text-xl font-bold text-ink">{p.name}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {p.description}
                </p>

                <p className="mt-6 text-xs font-bold tracking-[0.14em] text-ink uppercase">
                  Included Destinations
                </p>
                <ul className="mt-3 space-y-2">
                  {p.includes.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-ink-soft">
                      <CheckIcon className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                      {item}
                    </li>
                  ))}
                </ul>

                <p className="mt-6 text-xs font-bold tracking-[0.14em] text-ink uppercase">
                  Nearby Places
                </p>
                <ul className="mt-3 space-y-2">
                  {p.nearby.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <PinIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>

                <a
                  href={`https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(`Hello Shri Travels, I would like to enquire about ${p.name}.`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackCta({
                    ctaId: `package_${slug(p.name)}_book`,
                    ctaName: "WhatsApp Now",
                    ctaType: "whatsapp",
                    section: "Packages",
                    package: p.name,
                  })}
                  className="mt-7 inline-flex w-full items-center justify-center rounded-xl bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground shadow-soft transition-all hover:brightness-105"
                >
                  WhatsApp Now
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
