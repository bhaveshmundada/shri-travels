import { TESTIMONIALS } from "@/data/site";
import { Reveal } from "@/components/Reveal";
import { StarIcon } from "@/components/icons";

export function Testimonials() {
  return (
    <section id="testimonials" className="section-y bg-surface">
      <div className="container-x">
        <div className="mx-auto max-w-3xl text-center">
          <span className="eyebrow">Testimonials</span>
          <h2 className="mt-5 text-3xl font-extrabold text-ink sm:text-4xl">
            What Our Travellers Say
          </h2>
          <p className="mt-4 text-base text-muted-foreground">
            Real feedback from families, groups and businesses who travel with Shri Travels.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={(i % 3) * 70} className="h-full">
              <figure className="flex h-full flex-col rounded-3xl border border-border bg-card p-7 shadow-card">
                <div className="flex text-primary" aria-label="5 out of 5 stars">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <StarIcon key={s} />
                  ))}
                </div>
                <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-ink-soft">
                  {t.quote}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-border pt-5">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-primary-soft font-display text-sm font-bold text-primary">
                    {t.name.charAt(0)}
                  </span>
                  <span className="font-semibold text-ink">{t.name}</span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
