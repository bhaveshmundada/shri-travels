import { CONTACT } from "@/data/site";
import { PhoneIcon, WhatsAppIcon } from "@/components/icons";
import { trackCta } from "@/lib/tracking";

export function FinalCTA() {
  return (
    <section className="section-y bg-background">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-3xl bg-ink px-6 py-14 text-center sm:px-12 md:py-20">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -right-24 h-80 w-80 rounded-full bg-primary/25 blur-3xl"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-28 -left-20 h-80 w-80 rounded-full bg-primary/15 blur-3xl"
          />
          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-3xl font-extrabold text-background sm:text-4xl">
              Ready to Begin Your Spiritual Journey?
            </h2>
            <p className="mt-4 text-base text-background/75">
              Book your temple darshan cab today and travel with comfort, safety, and peace
              of mind.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
              <a
                href={`tel:${CONTACT.phoneDial}`}
                onClick={() =>
                  trackCta({
                    ctaId: "final_cta_book_now",
                    ctaName: "Call Now",
                    ctaType: "call",
                    section: "Final CTA",
                  })
                }
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-8 py-4 text-base font-semibold text-primary-foreground shadow-lift transition-all hover:brightness-110"
              >
                <PhoneIcon className="h-5 w-5" />
                Call Now
              </a>
              <a
                href={`https://wa.me/${CONTACT.whatsapp}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() =>
                  trackCta({
                    ctaId: "final_cta_whatsapp",
                    ctaName: "Whatsapp Now",
                    ctaType: "whatsapp",
                    section: "Final CTA",
                  })
                }
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-background/25 px-8 py-4 text-base font-semibold text-background transition-colors hover:bg-background/10"
              >
                <WhatsAppIcon className="h-5 w-5" />
                WhatsApp Now
              </a>
            </div>
            <a
              href={`tel:${CONTACT.phoneDial}`}
              onClick={() =>
                trackCta({
                  ctaId: "final_cta_phone_number",
                  ctaName: CONTACT.phone,
                  ctaType: "call",
                  section: "Final CTA",
                })
              }
              className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-background/80 hover:text-background"
            >
              <PhoneIcon className="h-4 w-4" />
              {CONTACT.phone}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
