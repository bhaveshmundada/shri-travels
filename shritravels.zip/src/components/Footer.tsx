import logo from "@/assets/shri-travels-logo.png.asset.json";
import { CONTACT, FOOTER } from "@/data/site";
import { PhoneIcon, PinIcon, WhatsAppIcon } from "@/components/icons";
import { trackCta } from "@/lib/tracking";

const LINK_HREF: Record<string, string> = {
  Home: "#home",
  "About Us": "#about",
  Contact: "#contact",
};

export function Footer() {
  return (
    <footer id="contact" className="border-t border-border bg-ink text-background/75">
      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <img
              src={logo.url}
              alt="Shri Travels logo"
              width={40}
              height={40}
              loading="lazy"
              className="h-10 w-10 object-contain"
            />
            <span className="font-display text-lg font-extrabold text-background">
              Shri Travels
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed">{FOOTER.tagline}</p>
        </div>

        <div>
          <h3 className="font-display text-base font-bold text-background">Quick Links</h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {FOOTER.quickLinks.map((l) => (
              <li key={l}>
                <a href={LINK_HREF[l] ?? "#home"} className="transition-colors hover:text-primary">
                  {l}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-base font-bold text-background">
            Temple Destinations
          </h3>
          <ul className="mt-4 space-y-2.5 text-sm">
            {FOOTER.temples.map((t) => (
              <li key={t}>
                <a href="#destinations" className="transition-colors hover:text-primary">
                  {t}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-base font-bold text-background">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex items-start gap-2.5">
              <PinIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span>{CONTACT.address}</span>
            </li>
            <li className="flex items-start gap-2.5">
              <PhoneIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <a
                href={`tel:${CONTACT.phoneDial}`}
                onClick={() =>
                  trackCta({
                    ctaId: "footer_call",
                    ctaName: CONTACT.phone,
                    ctaType: "call",
                    section: "Footer",
                  })
                }
                className="hover:text-primary"
              >
                {CONTACT.phone}
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <svg viewBox="0 0 24 24" className="mt-0.5 h-4 w-4 shrink-0 text-primary" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="5" width="18" height="14" rx="2" />
                <path d="m3 7 9 6 9-6" />
              </svg>
              <a href={`mailto:${CONTACT.email}`} className="hover:text-primary">
                {CONTACT.email}
              </a>
            </li>
          </ul>
          <a
            href={`https://wa.me/${CONTACT.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() =>
              trackCta({
                ctaId: "footer_whatsapp",
                ctaName: "WhatsApp Now",
                ctaType: "whatsapp",
                section: "Footer",
              })
            }
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-success px-5 py-3 text-sm font-semibold text-background transition-opacity hover:opacity-90"
          >
            <WhatsAppIcon className="h-4 w-4" />
            WhatsApp Now
          </a>
        </div>
      </div>

      <div className="border-t border-background/10">
        <div className="container-x flex flex-col items-center justify-between gap-3 py-6 text-xs sm:flex-row">
          <p>{FOOTER.copyright}</p>
          <a href="/admin" className="transition-colors hover:text-primary">
            Admin Login
          </a>
        </div>
      </div>
    </footer>
  );
}
