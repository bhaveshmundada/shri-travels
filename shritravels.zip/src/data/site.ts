export const CONTACT = {
  phone: "+91 8421444440",
  phoneDial: "+918421444440",
  whatsapp: "918421444440",
  email: "shritravels0704@gmail.com",
  address: "Near Bus Stand, Solapur - 413002  (Maharashtra)",
};

const MEDIA = "/img";

export const IMAGES = {
  hero: `${MEDIA}/Cab-in-Solapur-Shri-Travels.webp`,
};

export const STATS = [
  { value: 5, suffix: "+", label: "Travel Experience" },
  { value: 5223, suffix: "+", label: "Happy Customers" },
  { value: 20845, suffix: "+", label: "Trips Completed" },
  { value: 4.8, suffix: "", label: "Rating on Google", decimals: 1 },
];

export type Destination = {
  distance: string;
  location: string;
  title: string;
  description: string[];
  features: string[];
  image: string;
};

export const DESTINATIONS: Destination[] = [
  {
    distance: "40 km from Solapur",
    location: "Akkalkot",
    title: "Akkalkot Swami Samarth Temple",
    description: [
      "Visit the holy Shri Swami Samarth Maharaj Temple, one of Maharashtra’s most respected spiritual places. Thousands of devotees come here for blessings and peace.",
    ],
    features: ["Famous Swami Samarth Temple", "Calm & Devotional Environment"],
    image: `${MEDIA}/Shri-Swami-Samarth-Maharaj-Temple-Akkalkot.webp`,
  },
  {
    distance: "300 km from Solapur",
    location: "Gangapur",
    title: "Shri Dattatraya Temple",
    description: [
      "The Dattatraya Temple in Gangapur is a well-known and highly visites destination for devotees of Lord Dattatraya.",
      "People from across Maharashtra and beyond visit this holy place to pray, seek blessings, and experience deep spiritual peace in its calm and sacred surroundings.",
    ],
    features: ["Famous Temple for Lord Dattatreya", "Historic & Culturally Rich"],
    image: `${MEDIA}/Shri-Dattatraya-Temple-Gangapur.webp`,
  },
  {
    distance: "65 km from Solapur",
    location: "Pandharpur",
    title: "Pandharpur Vitthal - Rukmini Temple",
    description: [
      "Journey to the spiritual capital of Maharashtra – Pandharpur. The Vitthal-Rukmini temple is the heart of Varkari tradition, attracting millions of pilgrims annually, especially during the Ashadhi and Kartiki Ekadashi.",
    ],
    features: ["Famous Vitthal–Rukmini Temple", "Strong Spiritual Significance"],
    image: `${MEDIA}/Pandharpur-Vitthal-Rukmini-Temple.webp`,
  },
  {
    distance: "50 km from Solapur",
    location: "Tuljapur",
    title: "Tuljapur Darshan",
    description: [
      "Visit the famous Tulja Bhavani Temple, one of Maharashtra’s most important Shaktipeeths. A perfect spiritual trip for families and devotees seeking blessings.",
    ],
    features: ["Famous Swami Samarth Temple", "Calm & Devotional Environment"],
    image: `${MEDIA}/Solapur-to-Tuljapur-Cab-l-Shri-Travels.webp`,
  },
  {
    distance: "230 km from Solapur",
    location: "Kolhapur",
    title: "Kolhapur Darshan",
    description: [
      "Experience devotion at the Mahalaxmi Temple in Kolhapur, a revered pilgrimage site known for its divine energy and rich cultural heritage.",
      "Safe and comfortable journey for families and groups.",
    ],
    features: ["Major Shaktipeeth Visit"],
    image: `${MEDIA}/Solapur-to-Kolhapur-Cab-l-Shri-Travels.webp`,
  },
];

export const PACKAGES = [
  {
    name: "Akkalkot & Gangapur Darshan",
    duration: "1 Full Day",
    description:
      "A devotional one-day journey to Akkalkot and Gangapur with planned temple timings and smooth routes.",
    includes: [
      "Akkalkot – Swami Samarth Maharaj Temple",
      "Gangapur – Shri Dattatraya Temple",
    ],
    nearby: ["Akkalkot Vatavriksha", "Bhima-Amarja Sangam (near Gangapur)"],
  },
  {
    name: "Tuljapur & Pandharpur Darshan",
    duration: "1 Full Day",
    description:
      "A peaceful one-day temple tour from Solapur covering Tuljapur and Pandharpur, perfect for families and senior devotees.",
    includes: [
      "Tuljapur – Tulja Bhavani Temple",
      "Pandharpur – Vitthal–Rukmini Temple",
    ],
    nearby: ["Tuljapur Bhavani Mandir Market", "Chandrabhaga River Ghat"],
  },
  {
    name: "2-Day Complete Pilgrimage Tour",
    duration: "2 Full Day",
    description:
      "A complete spiritual experience covering all major temples around Solapur. Ideal for families, groups, and senior citizens.",
    includes: [
      "Visit All Major Temples (Tuljapur, Pandharpur, Akkalkot, Gangapur)",
      "Solapur Local Darshan (Solapur Siddheshwar Temple and local market visit)",
    ],
    nearby: ["Siddheshwar Temple", "Solapur Market", "Tuljapur & Pandharpur Ghats"],
  },
];

export const ROUTES = [
  {
    from: "Solapur",
    to: "Tuljapur",
    distance: "45 km",
    duration: "1 hour",
    description: [
      "Comfortable Solapur to Tuljapur cab service for your Tulja Bhavani darshan.",
      "Clean cars, trusted drivers, and timely service – every time.",
    ],
  },
  {
    from: "Solapur",
    to: "Pandharpur",
    distance: "70 km",
    duration: "1.5 hour",
    description: [
      "Book a reliable cab from Solapur to Pandharpur for a hassle-free temple visit.",
      "Clean cars, on-time pickup, and a comfortable ride for your family.",
    ],
  },
  {
    from: "Solapur",
    to: "Akkalkot",
    distance: "40 km",
    duration: "1 hour",
    description: [
      "Comfortable Solapur to Akkalkot cab service for Swami Samarth darshan.",
      "Clean cars, polite drivers, and on-time pickup – every time.",
    ],
  },
  {
    from: "Solapur",
    to: "Gangapur",
    distance: "110 km",
    duration: "2.5 hours",
    description: [
      "Comfortable Solapur to Gangapur cab service for Dattatraya darshan.",
      "On-time pickup, clean vehicles, and polite drivers—every single ride.",
    ],
  },
  {
    from: "Solapur",
    to: "Satara",
    distance: "250 km",
    duration: "2.5 hours",
    description: [
      "Travel from Solapur to Satara with our safe, comfortable, long-distance cab service.",
      "Ideal for family trips, work travel, or visiting popular attractions.",
    ],
  },
  {
    from: "Solapur",
    to: "Sangli",
    distance: "185 km",
    duration: "4 hours",
    description: [
      "Travel from Solapur to Sangli with our safe and comfortable cab service.",
      "Perfect for family trips, work travel, or visiting temples and markets.",
    ],
  },
  {
    from: "Solapur",
    to: "Pune",
    distance: "250 km",
    duration: "5 hours",
    description: [
      "Comfortable Solapur to Pune cab service for business or personal travel.",
      "Clean cars, polite drivers, and timely service – every time.",
    ],
  },
  {
    from: "Solapur",
    to: "Mumbai",
    distance: "390 km",
    duration: "7-8 hours",
    description: [
      "Travel from Solapur to Mumbai with our safe, comfortable long-distance cab service.",
      "Ideal for airport transfers, business trips, medical visits, and family travel.",
    ],
  },
  {
    from: "Solapur",
    to: "Kolhapur",
    distance: "250 km",
    duration: "5 hours",
    description: [
      "From Solapur to any city, any temple, or any destination—our cabs take you there safely and comfortably.",
      "Book a clean car with a trusted driver anytime.",
    ],
  },
];

export const FLEET = [
  {
    name: "Sedan",
    model: "Swift Dzire / Etios / Amaze",
    rate: "₹12/km",
    rateNote: "+ Toll & Parking",
    passengers: "4 Passengers",
    bags: "2-3 Bags",
    features: [
      "Budget-friendly fares",
      "Comfortable Seats",
      "Clean & AC cars",
      "GPS Tracking",
    ],
    image: `${MEDIA}/unnamed-1-e1760163209275.webp`,
  },
  {
    name: "SUV",
    model: "Ertiga / Kia Carens/ XUV500",
    rate: "₹14/km",
    rateNote: "+ Toll & Parking",
    passengers: "6-7 Passengers",
    bags: "2-3 Bags",
    features: [
      "Perfect for family travel",
      "Premium Comfort",
      "Extra Space",
      "Fully AC & safe",
    ],
    image: `${MEDIA}/Cab-in-Solapur-l-Ertiga.webp`,
  },
  {
    name: "Innova Crysta",
    model: "Innova / Innova Crysta",
    rate: "₹18/km",
    rateNote: "+ Toll & Parking",
    passengers: "6-7 Passengers",
    bags: "2-3 Bags",
    features: [
      "Premium Comfort",
      "Smooth ride experience",
      "Perfect for long rides",
      "Ideal for business or family trips",
    ],
    image: `${MEDIA}/unnamed-2-e1760163363407.webp`,
  },
  {
    name: "13 -20 Seater Tempo Traveller",
    model: "Tempo Traveller / Urbania",
    rate: "₹22/km",
    rateNote: "+ Toll & Parking",
    passengers: "12 -19 Passengers",
    bags: "7-8 Bags",
    features: [
      "AC & pushback seats",
      "Clean, spacious interiors",
      "Great for family trips",
      "Professional drivers",
    ],
    image: `${MEDIA}/Tempo-Traveller-on-Rent-l-Shri-Travels.webp`,
  },
  {
    name: "Luxury Urbania Tempo Traveller",
    model: "Tempo Traveller / Urbania",
    rate: "₹25/km",
    rateNote: "+ Toll & Parking",
    passengers: "17 Passengers",
    bags: "7-8 Bags",
    features: [
      "AC & pushback seats",
      "Clean, spacious interiors",
      "Great for family trips",
      "Professional drivers",
    ],
    image: `${MEDIA}/Force-Urbania-Tempo-Traveller-l-Shri-Travels-2.webp`,
  },
  {
    name: "Bus",
    model: "Ashok Leyland/ Bharat Benz/ Volvo",
    rate: "₹50/km",
    rateNote: "+ Toll & Parking",
    passengers: "35 – 50 Passengers",
    bags: "7-8 Bags",
    features: [
      "AC & pushback seats",
      "Entertainment System",
      "Great for family trips",
      "Professional drivers",
    ],
    image: `${MEDIA}/WhatsApp-Image-2025-11-15-at-11.36.32_8ae7fd1a.webp`,
  },
];

export const WHY_POINTS = [
  "5+ Years of Experience",
  "Trusted by 5,000+ Clients",
  "Completed 20,000+ Trips",
];

export const BENEFITS = [
  {
    title: "Clean & Comfortable",
    text: "Clean and well-maintained vehicles for a smooth and peaceful trip to holy places.",
  },
  {
    title: "24x7 Support",
    text: "Get help whenever you need it — we’re available 24/7 for all travel queries.",
  },
  {
    title: "Experienced Drivers",
    text: "Experienced drivers who know temple timings, routes, and local customs.",
  },
  {
    title: "Affordable Rates",
    text: "Transparent pricing with no hidden costs. Get the best rates in Solapur for temple trips.",
  },
];

export const TESTIMONIALS = [
  {
    quote:
      "“Our outstation family trip was perfectly arranged. Budget-friendly rates and on-time pickup made the journey stress-free. Definitely recommending to others!”",
    name: "Riya Thakur",
  },
  {
    quote:
      "“We booked for a corporate team outing. Excellent service with great comfort and professional driving. Everyone appreciated the smooth travel experience.”",
    name: "Kunal Patil",
  },
  {
    quote:
      "“The booking process was easy and the support team guided us very well. Safe driving and clean vehicle throughout the journey.",
    name: "Neha Kulkarni",
  },
  {
    quote:
      "“Affordable pricing and top-quality service. The driver had good route knowledge, which saved us time. Will surely travel again with you!”",
    name: "Harish Chavan",
  },
  {
    quote:
      "“Our weekend trip was super comfortable. The traveller was well-maintained and had premium features. Highly satisfied with the experience!”",
    name: "Shruti Mehta",
  },
];

export const FOOTER = {
  tagline:
    "Your trusted travel partner for comfortable and safe outstation cab services from Solapur.",
  quickLinks: ["Home", "About Us", "Contact"],
  temples: [
    "Akkalkot Swami Samarth",
    "Gangapur Dattatreya",
    "Pandharpur Vitthal",
    "Tuljapur Bhavani",
    "Other Holy Places",
  ],
  copyright: "© 2025 Shri Travels. All rights reserved.",
};
