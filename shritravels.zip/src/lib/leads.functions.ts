import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { sendTemplateEmail } from "@/lib/email-templates/send-email";

const leadAlertInput = z.object({
  name: z.string().min(1),
  mobile: z.string().min(1),
  pickup: z.string().min(1),
  drop: z.string().min(1),
  source: z.string().default("website"),
});

/**
 * Sends a lead notification email to the business inbox.
 * Fire-and-forget from the client after a lead is persisted — email delivery
 * never blocks the WhatsApp handoff. Failures are logged, not surfaced to the
 * customer, because the lead is already saved in the database.
 */
export const sendLeadAlert = createServerFn({ method: "POST" })
  .inputValidator((data) => leadAlertInput.parse(data))
  .handler(async ({ data }) => {
    try {
      await sendTemplateEmail("lead-alert", "", {
        templateData: {
          siteName: "Shri Travels",
          name: data.name,
          mobile: data.mobile,
          pickup: data.pickup,
          drop: data.drop,
          source: data.source,
        },
        idempotencyKey: `lead-${data.mobile}-${Date.now()}`,
      });
      return { ok: true as const };
    } catch (error) {
      console.error("[leads] failed to send lead alert email", error);
      return { ok: false as const };
    }
  });
