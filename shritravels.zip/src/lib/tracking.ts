import { supabase } from "@/integrations/supabase/client";

/**
 * Lightweight, anonymous CTA analytics.
 * - No personal data is recorded; only an opaque random session id.
 * - Every write is fire-and-forget so a click, call or WhatsApp handoff is
 *   never delayed by analytics.
 */

export type CtaType =
  | "booking"
  | "whatsapp"
  | "call"
  | "navigation"
  | "package"
  | "route"
  | "fleet"
  | "enquiry";

export type CtaMeta = {
  ctaId: string;
  ctaName: string;
  ctaType: CtaType;
  section: string;
  destination?: string;
  package?: string;
  route?: string;
  vehicle?: string;
};

export type EventName =
  | "cta_clicked"
  | "form_opened"
  | "form_started"
  | "form_submitted"
  | "lead_created"
  | "whatsapp_clicked"
  | "call_clicked";

const SESSION_KEY = "st_session_id";
const LAST_TOUCH_KEY = "st_last_cta";

export function getSessionId(): string {
  if (typeof window === "undefined") return "ssr";
  try {
    let id = window.localStorage.getItem(SESSION_KEY);
    if (!id) {
      id =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      window.localStorage.setItem(SESSION_KEY, id);
    }
    return id;
  } catch {
    return "anonymous";
  }
}

export function getDeviceType(): "mobile" | "tablet" | "desktop" {
  if (typeof window === "undefined") return "desktop";
  const w = window.innerWidth;
  if (w < 768) return "mobile";
  if (w < 1024) return "tablet";
  return "desktop";
}

function getPage(): string {
  return typeof window === "undefined" ? "/" : window.location.pathname;
}

/** Stores the most recent CTA interaction for last-touch lead attribution. */
export function setLastTouch(meta: CtaMeta) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(LAST_TOUCH_KEY, JSON.stringify(meta));
  } catch {
    /* ignore */
  }
}

export function getLastTouch(): CtaMeta | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.sessionStorage.getItem(LAST_TOUCH_KEY);
    return raw ? (JSON.parse(raw) as CtaMeta) : null;
  } catch {
    return null;
  }
}

export function clearLastTouch() {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(LAST_TOUCH_KEY);
  } catch {
    /* ignore */
  }
}

export function trackEvent(
  eventName: EventName,
  meta?: CtaMeta | null,
  extra?: { leadId?: string },
) {
  if (typeof window === "undefined") return;
  const row = {
    event_name: eventName,
    cta_id: meta?.ctaId ?? null,
    cta_name: meta?.ctaName ?? null,
    cta_type: meta?.ctaType ?? null,
    section: meta?.section ?? null,
    destination: meta?.destination ?? null,
    package: meta?.package ?? null,
    route: meta?.route ?? null,
    vehicle: meta?.vehicle ?? null,
    page: getPage(),
    device_type: getDeviceType(),
    session_id: getSessionId(),
    lead_id: extra?.leadId ?? null,
  };
  // Never await: the user's action continues immediately.
  void supabase
    .from("cta_events")
    .insert(row)
    .then(() => undefined);
}

/** Records a CTA click and remembers it as the last touch before a lead. */
export function trackCta(meta: CtaMeta) {
  setLastTouch(meta);
  trackEvent("cta_clicked", meta);
  if (meta.ctaType === "whatsapp") trackEvent("whatsapp_clicked", meta);
  if (meta.ctaType === "call") trackEvent("call_clicked", meta);
}

/** Slug helper so content names produce stable, descriptive CTA ids. */
export function slug(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}
