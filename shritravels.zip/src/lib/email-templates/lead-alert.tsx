import * as React from 'react'

import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'

interface LeadAlertEmailProps {
  siteName?: string
  name?: string
  mobile?: string
  pickup?: string
  drop?: string
  source?: string
}

const BRAND = '#E8730C'

export const LeadAlertEmail = ({
  siteName = 'Shri Travels',
  name = '—',
  mobile = '—',
  pickup = '—',
  drop = '—',
  source = 'website',
}: LeadAlertEmailProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>New booking enquiry from {name} — {mobile}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>
          New Booking Enquiry 🔔
        </Heading>
        <Text style={text}>
          You received a new enquiry on <strong>{siteName}</strong>. Here are the
          customer details:
        </Text>

        <Section style={card}>
          <Row label="Name" value={name} />
          <Row label="Mobile" value={mobile} />
          <Row label="Pickup Location" value={pickup} />
          <Row label="Drop Location" value={drop} />
          <Row label="Source" value={source} />
        </Section>

        <Hr style={hr} />
        <Text style={footer}>
          This lead was also saved to your admin dashboard at book.shritravels.in/admin.
          Reply to the customer promptly to improve conversion.
        </Text>
      </Container>
    </Body>
  </Html>
)

const Row = ({ label, value }: { label: string; value: string }) => (
  <Section style={row}>
    <Text style={labelStyle}>{label}</Text>
    <Text style={valueStyle}>{value}</Text>
  </Section>
)

const main = { backgroundColor: '#F6F5F2', fontFamily: 'Arial, sans-serif', padding: '24px 0' }
const container = { backgroundColor: '#ffffff', padding: '28px 28px', borderRadius: '14px', maxWidth: '560px', margin: '0 auto' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, color: BRAND, margin: '0 0 16px' }
const text = { fontSize: '14px', color: '#44464c', lineHeight: '1.6', margin: '0 0 20px' }
const card = { backgroundColor: '#FBF4EE', border: `1px solid ${BRAND}33`, borderRadius: '12px', padding: '4px 18px', margin: '0 0 8px' }
const row = { padding: '12px 0', borderBottom: '1px solid #EFE7DF' }
const labelStyle = { fontSize: '11px', fontWeight: 'bold' as const, color: '#8a6b46', textTransform: 'uppercase' as const, letterSpacing: '0.06em', margin: '0 0 2px' }
const valueStyle = { fontSize: '15px', color: '#1b1c20', margin: '0' }
const hr = { borderColor: '#ECEAE5', margin: '24px 0' }
const footer = { fontSize: '12px', color: '#9a9aa0', lineHeight: '1.5', margin: '0' }

export default LeadAlertEmail
