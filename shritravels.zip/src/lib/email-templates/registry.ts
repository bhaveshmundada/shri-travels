import type { ComponentType } from 'react'
import { CONTACT } from '@/data/site'

import { LeadAlertEmail } from './lead-alert'

export interface TemplateEntry {
  component: ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  displayName?: string
  previewData?: Record<string, any>
  /** Fixed recipient — overrides caller-provided recipientEmail when set. */
  to?: string
}

/**
 * Template registry — maps template names to their React Email components.
 * Import and register new templates here after creating them in this directory.
 *
 * Example:
 *   import { template as welcomeTemplate } from './welcome'
 *   // then add to TEMPLATES: 'welcome': welcomeTemplate
 */
export const TEMPLATES: Record<string, TemplateEntry> = {
  'lead-alert': {
    component: LeadAlertEmail,
    displayName: 'New Lead Alert',
    to: CONTACT.email,
    subject: (data) =>
      `New Lead: ${data?.['name'] ?? 'New enquiry'} — ${data?.['mobile'] ?? ''}`,
    previewData: {
      siteName: 'Shri Travels',
      name: 'Rajesh Kumar',
      mobile: '+91 98765 43210',
      pickup: 'Solapur Bus Stand',
      drop: 'Pandharpur Vitthal Temple',
      source: 'destinations',
    },
  },
}
