import { createServerFn } from "@tanstack/react-start";

/**
 * Returns the Google Analytics 4 measurement ID from the server-side secret
 * store. The value is public by nature (it ships in the page HTML) but is
 * kept in the secret store so it can be rotated without a code change.
 */
export const getGaMeasurementId = createServerFn({ method: "GET" }).handler(
  () => process.env["GOOGLE_ANALYTICS_MEASUREMENT_ID"]?.trim() || null,
);
