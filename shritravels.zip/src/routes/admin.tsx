import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";

import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/shri-travels-logo.png.asset.json";

type Lead = {
  id: string;
  name: string;
  mobile: string;
  pickup_location: string;
  drop_location: string;
  source: string | null;
  status: string;
  created_at: string;
  cta_id: string | null;
  cta_name: string | null;
  cta_section: string | null;
  cta_type: string | null;
  page: string | null;
  device_type: string | null;
  session_id: string | null;
};

type CtaEvent = {
  id: string;
  event_name: string;
  cta_id: string | null;
  cta_name: string | null;
  cta_type: string | null;
  section: string | null;
  page: string | null;
  destination: string | null;
  package: string | null;
  route: string | null;
  vehicle: string | null;
  device_type: string | null;
  session_id: string;
  lead_id: string | null;
  created_at: string;
};

const STATUSES = ["New", "Contacted", "Converted", "Closed"];

const RANGES = ["Today", "Yesterday", "Last 7 Days", "Last 30 Days", "All Time"] as const;
type RangeKey = (typeof RANGES)[number];

const EVENT_NAMES = [
  "cta_clicked",
  "form_opened",
  "form_started",
  "form_submitted",
  "lead_created",
  "whatsapp_clicked",
  "call_clicked",
];

function rangeBounds(key: RangeKey): { from: number; to: number } {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const day = 86_400_000;
  switch (key) {
    case "Today":
      return { from: startOfToday, to: Infinity };
    case "Yesterday":
      return { from: startOfToday - day, to: startOfToday };
    case "Last 7 Days":
      return { from: startOfToday - 6 * day, to: Infinity };
    case "Last 30 Days":
      return { from: startOfToday - 29 * day, to: Infinity };
    default:
      return { from: -Infinity, to: Infinity };
  }
}

function pct(part: number, whole: number) {
  if (!whole) return "0%";
  return `${((part / whole) * 100).toFixed(2)}%`;
}

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin Dashboard – Shri Travels" },
      { name: "description", content: "Secure lead management dashboard for Shri Travels." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Admin Dashboard – Shri Travels" },
      {
        property: "og:description",
        content: "Secure lead management dashboard for Shri Travels.",
      },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!ready) {
    return (
      <div className="grid min-h-screen place-items-center bg-surface text-sm text-muted-foreground">
        Loading…
      </div>
    );
  }

  return session ? <Dashboard email={session.user.email ?? ""} /> : <LoginCard />;
}

function LoginCard() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    setBusy(false);
  }

  const input =
    "h-12 w-full rounded-xl border border-input bg-background px-4 text-base outline-none focus:border-primary focus:ring-2 focus:ring-ring/25";

  return (
    <div className="grid min-h-screen place-items-center bg-surface px-5 py-12">
      <div className="w-full max-w-md rounded-3xl border border-border bg-card p-8 shadow-lift">
        <div className="flex items-center gap-2.5">
          <img src={logo.url} alt="" width={40} height={40} className="h-10 w-10 object-contain" />
          <span className="font-display text-lg font-extrabold text-ink">Shri Travels</span>
        </div>
        <h1 className="mt-6 font-display text-2xl font-extrabold text-ink">Admin Sign In</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Authorised staff only. Leads are protected by database-level access rules.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="email" className="mb-1.5 block text-sm font-semibold text-ink-soft">
              Username
            </label>
            <input
              id="email"
              type="email"
              required
              autoComplete="username"
              className={input}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="password" className="mb-1.5 block text-sm font-semibold text-ink-soft">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              minLength={6}
              autoComplete="current-password"
              className={input}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {error ? (
            <p className="rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-xl bg-primary px-6 py-3.5 text-base font-semibold text-primary-foreground transition-all hover:brightness-105 disabled:opacity-70"
          >
            {busy ? "Please wait…" : "Sign In"}
          </button>
        </form>

        <a
          href="/"
          className="mt-3 block text-center text-sm text-muted-foreground hover:text-ink"
        >
          Back to website
        </a>
      </div>
    </div>
  );
}

function Dashboard({ email }: { email: string }) {
  const [tab, setTab] = useState<"leads" | "analytics">("leads");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [events, setEvents] = useState<CtaEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [range, setRange] = useState<RangeKey>("Last 30 Days");

  const load = useCallback(async () => {
    setLoading(true);
    const [leadRes, eventRes] = await Promise.all([
      supabase.from("leads").select("*").order("created_at", { ascending: false }),
      supabase
        .from("cta_events")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20000),
    ]);
    if (leadRes.error || eventRes.error) {
      setError(leadRes.error?.message ?? eventRes.error?.message ?? null);
    } else {
      setError(null);
      setLeads((leadRes.data ?? []) as Lead[]);
      setEvents((eventRes.data ?? []) as CtaEvent[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const bounds = useMemo(() => rangeBounds(range), [range]);
  const inRange = useCallback(
    (iso: string) => {
      const t = new Date(iso).getTime();
      return t >= bounds.from && t < bounds.to;
    },
    [bounds],
  );

  const rangedLeads = useMemo(() => leads.filter((l) => inRange(l.created_at)), [leads, inRange]);
  const rangedEvents = useMemo(
    () => events.filter((e) => inRange(e.created_at)),
    [events, inRange],
  );

  return (
    <div className="min-h-screen bg-surface">
      <header className="border-b border-border bg-card">
        <div className="container-x flex flex-wrap items-center justify-between gap-3 py-4">
          <div className="flex items-center gap-2.5">
            <img src={logo.url} alt="" width={36} height={36} className="h-9 w-9 object-contain" />
            <div>
              <p className="font-display text-base font-extrabold text-ink">Lead Dashboard</p>
              <p className="text-xs text-muted-foreground">{email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/"
              className="rounded-xl border border-border px-4 py-2.5 text-sm font-semibold text-ink hover:bg-muted"
            >
              View site
            </a>
            <button
              type="button"
              onClick={() => supabase.auth.signOut()}
              className="rounded-xl bg-ink px-4 py-2.5 text-sm font-semibold text-background"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="container-x py-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex rounded-xl border border-border bg-card p-1">
            {(
              [
                ["leads", "Leads"],
                ["analytics", "CTA Analytics"],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`rounded-lg px-4 py-2 text-sm font-semibold transition-colors ${
                  tab === key
                    ? "bg-primary text-primary-foreground"
                    : "text-ink-soft hover:bg-muted"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={range}
              onChange={(e) => setRange(e.target.value as RangeKey)}
              className="h-11 rounded-xl border border-input bg-background px-3 text-sm"
            >
              {RANGES.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => void load()}
              className="h-11 rounded-xl border border-border px-4 text-sm font-semibold text-ink hover:bg-muted"
            >
              Refresh
            </button>
          </div>
        </div>

        {error ? (
          <p className="mt-4 rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {error}
          </p>
        ) : null}

        {tab === "leads" ? (
          <LeadsPanel leads={rangedLeads} loading={loading} reload={load} setError={setError} />
        ) : (
          <AnalyticsPanel events={rangedEvents} leads={rangedLeads} loading={loading} />
        )}
      </main>
    </div>
  );
}

/* ---------------- Leads ---------------- */

function LeadsPanel({
  leads,
  loading,
  reload,
  setError,
}: {
  leads: Lead[];
  loading: boolean;
  reload: () => Promise<void>;
  setError: (v: string | null) => void;
}) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [rows, setRows] = useState<Lead[]>(leads);
  const [detail, setDetail] = useState<Lead | null>(null);

  useEffect(() => setRows(leads), [leads]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((l) => {
      if (filter !== "All" && l.status !== filter) return false;
      if (!q) return true;
      return [
        l.name,
        l.mobile,
        l.pickup_location,
        l.drop_location,
        l.source ?? "",
        l.cta_name ?? "",
        l.cta_section ?? "",
      ]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [rows, query, filter]);

  async function updateStatus(id: string, status: string) {
    setRows((prev) => prev.map((l) => (l.id === id ? { ...l, status } : l)));
    const { error } = await supabase.from("leads").update({ status }).eq("id", id);
    if (error) {
      setError(error.message);
      void reload();
    }
  }

  function exportCsv() {
    const data = [
      ["Date", "Name", "Mobile", "Pickup", "Drop", "CTA Source", "Section", "Device", "Status"],
      ...filtered.map((l) => [
        new Date(l.created_at).toLocaleString(),
        l.name,
        l.mobile,
        l.pickup_location,
        l.drop_location,
        l.cta_name ?? "",
        l.cta_section ?? l.source ?? "",
        l.device_type ?? "",
        l.status,
      ]),
    ];
    const csv = data
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `shri-travels-leads-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const counts = useMemo(() => {
    const today = new Date().toDateString();
    return {
      total: rows.length,
      today: rows.filter((l) => new Date(l.created_at).toDateString() === today).length,
      newCount: rows.filter((l) => l.status === "New").length,
      converted: rows.filter((l) => l.status === "Converted").length,
    };
  }, [rows]);

  return (
    <>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Total Leads", value: counts.total },
          { label: "Today", value: counts.today },
          { label: "New", value: counts.newCount },
          { label: "Converted", value: counts.converted },
        ].map((c) => (
          <Kpi key={c.label} label={c.label} value={c.value} />
        ))}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <input
          placeholder="Search name, mobile, location, CTA…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="h-11 min-w-56 flex-1 rounded-xl border border-input bg-background px-4 text-sm outline-none focus:border-primary"
        />
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="h-11 rounded-xl border border-input bg-background px-3 text-sm"
        >
          {["All", ...STATUSES].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button
          type="button"
          onClick={exportCsv}
          className="h-11 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground"
        >
          Export CSV
        </button>
      </div>

      <div className="mt-5 overflow-hidden rounded-2xl border border-border bg-card shadow-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-3xl text-left text-sm">
            <thead className="bg-muted/60 text-xs tracking-wide text-muted-foreground uppercase">
              <tr>
                {[
                  "Date",
                  "Name",
                  "Mobile",
                  "Pickup",
                  "Drop",
                  "CTA Source",
                  "Section",
                  "Status",
                  "",
                ].map((h, i) => (
                  <th key={`${h}-${i}`} className="px-4 py-3 font-bold whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-muted-foreground">
                    Loading leads…
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-10 text-center text-muted-foreground">
                    No leads found.
                  </td>
                </tr>
              ) : (
                filtered.map((l) => (
                  <tr key={l.id} className="border-t border-border align-top">
                    <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                      {new Date(l.created_at).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 font-semibold text-ink">{l.name}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <a href={`tel:${l.mobile}`} className="text-primary hover:underline">
                        {l.mobile}
                      </a>
                    </td>
                    <td className="px-4 py-3">{l.pickup_location}</td>
                    <td className="px-4 py-3">{l.drop_location}</td>
                    <td className="px-4 py-3">{l.cta_name ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {l.cta_section ?? l.source ?? "—"}
                    </td>
                    <td className="px-4 py-3">
                      <select
                        value={l.status}
                        onChange={(e) => void updateStatus(l.id, e.target.value)}
                        className="h-9 rounded-lg border border-input bg-background px-2 text-sm"
                      >
                        {STATUSES.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => setDetail(l)}
                        className="rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-ink hover:bg-muted"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {detail ? <LeadDetail lead={detail} onClose={() => setDetail(null)} /> : null}
    </>
  );
}

function LeadDetail({ lead, onClose }: { lead: Lead; onClose: () => void }) {
  const rows: Array<[string, string]> = [
    ["Name", lead.name],
    ["Mobile Number", lead.mobile],
    ["Pickup Location", lead.pickup_location],
    ["Drop Location", lead.drop_location],
    ["Lead Date/Time", new Date(lead.created_at).toLocaleString()],
    ["Lead Status", lead.status],
    ["CTA Source", lead.cta_name ?? "—"],
    ["CTA ID", lead.cta_id ?? "—"],
    ["CTA Name", lead.cta_name ?? "—"],
    ["Section", lead.cta_section ?? "—"],
    ["Page", lead.page ?? "—"],
    ["Device", lead.device_type ?? "—"],
    ["Source", lead.source ?? "—"],
  ];
  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-card p-6 shadow-lift sm:rounded-3xl sm:p-8">
        <div className="flex items-start justify-between gap-4">
          <h2 className="font-display text-xl font-extrabold text-ink">Lead Details</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted-foreground hover:bg-muted"
          >
            ✕
          </button>
        </div>
        <dl className="mt-5 divide-y divide-border">
          {rows.map(([k, v]) => (
            <div key={k} className="flex justify-between gap-6 py-2.5 text-sm">
              <dt className="text-muted-foreground">{k}</dt>
              <dd className="text-right font-semibold text-ink">{v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}

/* ---------------- Analytics ---------------- */

function AnalyticsPanel({
  events,
  leads,
  loading,
}: {
  events: CtaEvent[];
  leads: Lead[];
  loading: boolean;
}) {
  const [ctaFilter, setCtaFilter] = useState("All");
  const [sectionFilter, setSectionFilter] = useState("All");
  const [deviceFilter, setDeviceFilter] = useState("All");
  const [eventFilter, setEventFilter] = useState("All");

  const ctaOptions = useMemo(
    () => Array.from(new Set(events.map((e) => e.cta_id).filter(Boolean) as string[])).sort(),
    [events],
  );
  const sectionOptions = useMemo(
    () => Array.from(new Set(events.map((e) => e.section).filter(Boolean) as string[])).sort(),
    [events],
  );
  const deviceOptions = useMemo(
    () => Array.from(new Set(events.map((e) => e.device_type).filter(Boolean) as string[])).sort(),
    [events],
  );

  const filtered = useMemo(
    () =>
      events.filter(
        (e) =>
          (ctaFilter === "All" || e.cta_id === ctaFilter) &&
          (sectionFilter === "All" || e.section === sectionFilter) &&
          (deviceFilter === "All" || e.device_type === deviceFilter) &&
          (eventFilter === "All" || e.event_name === eventFilter),
      ),
    [events, ctaFilter, sectionFilter, deviceFilter, eventFilter],
  );

  // KPIs ignore the event-type filter so the funnel stays comparable.
  const funnelBase = useMemo(
    () =>
      events.filter(
        (e) =>
          (ctaFilter === "All" || e.cta_id === ctaFilter) &&
          (sectionFilter === "All" || e.section === sectionFilter) &&
          (deviceFilter === "All" || e.device_type === deviceFilter),
      ),
    [events, ctaFilter, sectionFilter, deviceFilter],
  );

  const count = useCallback(
    (name: string) => funnelBase.filter((e) => e.event_name === name).length,
    [funnelBase],
  );

  const leadCount = useMemo(() => {
    if (ctaFilter === "All" && sectionFilter === "All" && deviceFilter === "All")
      return leads.length;
    return leads.filter(
      (l) =>
        (ctaFilter === "All" || l.cta_id === ctaFilter) &&
        (sectionFilter === "All" || l.cta_section === sectionFilter) &&
        (deviceFilter === "All" || l.device_type === deviceFilter),
    ).length;
  }, [leads, ctaFilter, sectionFilter, deviceFilter]);

  type Agg = {
    key: string;
    name: string;
    section: string;
    clicks: number;
    opens: number;
    submits: number;
    leads: number;
  };

  const byCta = useMemo(() => {
    const map = new Map<string, Agg>();
    const get = (key: string, name: string, section: string) => {
      let a = map.get(key);
      if (!a) {
        a = { key, name, section, clicks: 0, opens: 0, submits: 0, leads: 0 };
        map.set(key, a);
      }
      return a;
    };
    for (const e of funnelBase) {
      if (!e.cta_id) continue;
      const a = get(e.cta_id, e.cta_name ?? e.cta_id, e.section ?? "—");
      if (e.event_name === "cta_clicked") a.clicks += 1;
      if (e.event_name === "form_opened") a.opens += 1;
      if (e.event_name === "form_submitted") a.submits += 1;
      if (e.event_name === "lead_created") a.leads += 1;
    }
    return Array.from(map.values()).sort((x, y) => y.clicks - x.clicks);
  }, [funnelBase]);

  const bySection = useMemo(() => {
    const map = new Map<string, Agg>();
    for (const e of funnelBase) {
      const key = e.section ?? "—";
      let a = map.get(key);
      if (!a) {
        a = { key, name: key, section: key, clicks: 0, opens: 0, submits: 0, leads: 0 };
        map.set(key, a);
      }
      if (e.event_name === "cta_clicked") a.clicks += 1;
      if (e.event_name === "form_opened") a.opens += 1;
      if (e.event_name === "form_submitted") a.submits += 1;
      if (e.event_name === "lead_created") a.leads += 1;
    }
    return Array.from(map.values()).sort((x, y) => y.clicks - x.clicks);
  }, [funnelBase]);

  const byDevice = useMemo(() => {
    const map = new Map<string, Agg>();
    for (const e of funnelBase) {
      const key = e.device_type ?? "unknown";
      let a = map.get(key);
      if (!a) {
        a = { key, name: key, section: key, clicks: 0, opens: 0, submits: 0, leads: 0 };
        map.set(key, a);
      }
      if (e.event_name === "cta_clicked") a.clicks += 1;
      if (e.event_name === "form_opened") a.opens += 1;
      if (e.event_name === "form_submitted") a.submits += 1;
      if (e.event_name === "lead_created") a.leads += 1;
    }
    return Array.from(map.values()).sort((x, y) => y.clicks - x.clicks);
  }, [funnelBase]);

  const select = "h-11 rounded-xl border border-input bg-background px-3 text-sm";

  if (loading) {
    return <p className="mt-8 text-sm text-muted-foreground">Loading analytics…</p>;
  }

  return (
    <div className="mt-6 space-y-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
        <Kpi label="CTA Clicks" value={count("cta_clicked")} />
        <Kpi label="Form Opens" value={count("form_opened")} />
        <Kpi label="Form Starts" value={count("form_started")} />
        <Kpi label="Form Submissions" value={count("form_submitted")} />
        <Kpi label="Leads" value={leadCount} />
        <Kpi label="WhatsApp Clicks" value={count("whatsapp_clicked")} />
        <Kpi label="Call Clicks" value={count("call_clicked")} />
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <select value={ctaFilter} onChange={(e) => setCtaFilter(e.target.value)} className={select}>
          {["All", ...ctaOptions].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
        <select
          value={sectionFilter}
          onChange={(e) => setSectionFilter(e.target.value)}
          className={select}
        >
          {["All", ...sectionOptions].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
        <select
          value={deviceFilter}
          onChange={(e) => setDeviceFilter(e.target.value)}
          className={select}
        >
          {["All", ...deviceOptions].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
        <select
          value={eventFilter}
          onChange={(e) => setEventFilter(e.target.value)}
          className={select}
        >
          {["All", ...EVENT_NAMES].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      </div>

      <AggTable title="CTA Performance" firstHeader="CTA Name" rows={byCta} showSection />
      <AggTable title="Performance by Section" firstHeader="Section" rows={bySection} />
      <AggTable title="Performance by Device" firstHeader="Device" rows={byDevice} />

      <section>
        <h2 className="font-display text-lg font-extrabold text-ink">Recent CTA Events</h2>
        <div className="mt-3 overflow-hidden rounded-2xl border border-border bg-card shadow-card">
          <div className="overflow-x-auto">
            <table className="w-full min-w-3xl text-left text-sm">
              <thead className="bg-muted/60 text-xs tracking-wide text-muted-foreground uppercase">
                <tr>
                  {["Time", "Event", "CTA", "Section", "Device", "Context"].map((h) => (
                    <th key={h} className="px-4 py-3 font-bold whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                      No data yet
                    </td>
                  </tr>
                ) : (
                  filtered.slice(0, 100).map((e) => (
                    <tr key={e.id} className="border-t border-border">
                      <td className="px-4 py-2.5 whitespace-nowrap text-muted-foreground">
                        {new Date(e.created_at).toLocaleString()}
                      </td>
                      <td className="px-4 py-2.5 font-semibold text-ink">{e.event_name}</td>
                      <td className="px-4 py-2.5">{e.cta_name ?? "—"}</td>
                      <td className="px-4 py-2.5 text-muted-foreground">{e.section ?? "—"}</td>
                      <td className="px-4 py-2.5 text-muted-foreground">
                        {e.device_type ?? "—"}
                      </td>
                      <td className="px-4 py-2.5 text-muted-foreground">
                        {e.destination ?? e.package ?? e.route ?? e.vehicle ?? "—"}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}

function AggTable({
  title,
  firstHeader,
  rows,
  showSection = false,
}: {
  title: string;
  firstHeader: string;
  rows: Array<{
    key: string;
    name: string;
    section: string;
    clicks: number;
    opens: number;
    submits: number;
    leads: number;
  }>;
  showSection?: boolean;
}) {
  return (
    <section>
      <h2 className="font-display text-lg font-extrabold text-ink">{title}</h2>
      <div className="mt-3 overflow-hidden rounded-2xl border border-border bg-card shadow-card">
        <div className="overflow-x-auto">
          <table className="w-full min-w-3xl text-left text-sm">
            <thead className="bg-muted/60 text-xs tracking-wide text-muted-foreground uppercase">
              <tr>
                <th className="px-4 py-3 font-bold whitespace-nowrap">{firstHeader}</th>
                {showSection ? (
                  <th className="px-4 py-3 font-bold whitespace-nowrap">Section</th>
                ) : null}
                {["Clicks", "Forms Opened", "Forms Submitted", "Leads", "Conversion Rate"].map(
                  (h) => (
                    <th key={h} className="px-4 py-3 font-bold whitespace-nowrap">
                      {h}
                    </th>
                  ),
                )}
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td
                    colSpan={showSection ? 7 : 6}
                    className="px-4 py-10 text-center text-muted-foreground"
                  >
                    No data yet
                  </td>
                </tr>
              ) : (
                rows.map((r) => (
                  <tr key={r.key} className="border-t border-border">
                    <td className="px-4 py-2.5 font-semibold text-ink">{r.name}</td>
                    {showSection ? (
                      <td className="px-4 py-2.5 text-muted-foreground">{r.section}</td>
                    ) : null}
                    <td className="px-4 py-2.5">{r.clicks}</td>
                    <td className="px-4 py-2.5">{r.opens}</td>
                    <td className="px-4 py-2.5">{r.submits}</td>
                    <td className="px-4 py-2.5">{r.leads}</td>
                    <td className="px-4 py-2.5 font-semibold text-ink">
                      {pct(r.leads, r.clicks)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function Kpi({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
      <p className="text-sm font-semibold text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-3xl font-extrabold text-ink">{value}</p>
    </div>
  );
}
