import { createFileRoute } from "@tanstack/react-router";

import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Stats } from "@/components/Stats";
import { Destinations } from "@/components/Destinations";
import { Packages } from "@/components/Packages";
import { RoutesSection } from "@/components/RoutesSection";
import { Fleet } from "@/components/Fleet";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { Testimonials } from "@/components/Testimonials";
import { FinalCTA } from "@/components/FinalCTA";
import { Footer } from "@/components/Footer";
import { MobileCTA } from "@/components/MobileCTA";
import { CONTACT, ROUTES } from "@/data/site";

const TITLE = "Shri Travels Solapur – Reliable Cab, Taxi & Tour Services in Solapur";
const DESCRIPTION =
  "Trusted & affordable Solapur cab services for local and outstation trips, airport transfers and temple darshan at Pandharpur, Akkalkot, Tuljapur & Gangapur. 24×7 support.";

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "TaxiService",
  name: "Shri Travels",
  description: DESCRIPTION,
  telephone: CONTACT.phone,
  email: CONTACT.email,
  address: {
    "@type": "PostalAddress",
    streetAddress: "Near Bus Stand",
    addressLocality: "Solapur",
    postalCode: "413002",
    addressRegion: "Maharashtra",
    addressCountry: "IN",
  },
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: "4.8",
    reviewCount: "5223",
  },
  areaServed: ROUTES.map((r) => r.to),
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [
      { rel: "canonical", href: "https://shritravels.in/" },
      { rel: "preload", as: "image", href: "/img/Cab-in-Solapur-Shri-Travels.webp", fetchPriority: "high" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify(jsonLd),
      },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
      <div className="min-h-screen bg-background pb-20 lg:pb-0">
        <Header />
        <main>
          <Hero />
          <Stats />
          <Destinations />
          <Packages />
          <RoutesSection />
          <Fleet />
          <WhyChooseUs />
          <Testimonials />
          <FinalCTA />
        </main>
        <Footer />
        <MobileCTA />
      </div>
  );
}
