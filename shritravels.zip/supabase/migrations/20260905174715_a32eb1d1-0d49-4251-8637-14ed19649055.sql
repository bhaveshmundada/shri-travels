CREATE TABLE public.cta_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_name text NOT NULL,
  cta_id text,
  cta_name text,
  cta_type text,
  page text,
  section text,
  destination text,
  package text,
  route text,
  vehicle text,
  device_type text,
  session_id text NOT NULL,
  lead_id uuid REFERENCES public.leads(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX cta_events_created_at_idx ON public.cta_events (created_at DESC);
CREATE INDEX cta_events_cta_id_idx ON public.cta_events (cta_id);
CREATE INDEX cta_events_session_idx ON public.cta_events (session_id);

GRANT INSERT ON public.cta_events TO anon, authenticated;
GRANT SELECT ON public.cta_events TO authenticated;
GRANT ALL ON public.cta_events TO service_role;

ALTER TABLE public.cta_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can record a cta event"
  ON public.cta_events FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Admins can read cta events"
  ON public.cta_events FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

ALTER TABLE public.leads
  ADD COLUMN cta_id text,
  ADD COLUMN cta_name text,
  ADD COLUMN cta_section text,
  ADD COLUMN cta_type text,
  ADD COLUMN page text,
  ADD COLUMN device_type text,
  ADD COLUMN session_id text;